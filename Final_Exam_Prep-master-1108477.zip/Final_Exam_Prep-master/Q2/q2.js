// JavaScript Document

class Person {
  //initiate Person class
  constructor(name, age, gender, interests) { //Person class must include name, age, gender, interests
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.interests = interests;
  }
  //calls the Person created and prints a greeting and the name of the person called on
  greeting() {
    console.log(`Hi! I'm ${this.name}`);
  };
  //Prints name of the person then a farwell response
  bye() {
    console.log(`${this.name.} has left the building. Bye for now!`);
  };
}

//Person created named Parth, age 20, male,intrests include JavaScript, Java, PHP
let parth = new Person('Parth', 20, 'male', ['JavaScript', 'Java', 'PHP']);

//Person created named Harmanpreet, age 22, male,intrests include JavaScript, C, Relational DataBase
let harmanpreet = new Person('Harmanpreet', 22, 'male', ['JavaScript', 'C#', 'Relational DataBase']);


class Teacher extends Person {//initiate Teacher class
  constructor(name, age, gender, interests, subject, grade) {//Person class must include name, age, gender, interests, Subject, grade
    super(name, age, gender, interests);//Sends name, age, gender, interests to the Person class which Teacher can access all methods that relate to Person.
    // subject and grade are specific to Teacher
    this.subject = subject;
    this.grade = grade;
  }
}


let Carter = new Teacher('Carter', 85, 'female', ['Video games', 'Texting', 'Youtube'], "Quamtum Computers", "100%");
